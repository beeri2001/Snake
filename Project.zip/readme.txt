English:
open the project in vscode.

1. open a terminal in vs code
2. type:  npm install
this should install all needed node modules from the package.json
3. type: npm audit fix
this usually fixes most vulnerabilities and is just good the tun after install in general

after this you can put your own .ts files in hierarchy or put code in the app.ts
if you want to run the project and subsequently close
1. type: npm run dev in the terminal
this will start and open the application.
2. ctrl + c in the terminal, than you get a prompt if you want to terminate. press Y and hit enter

nerderlands: 
open het project in vscode

1. open een terminal in vscode
2. type: npm install in de terminal
dit installeert alle benodigde node modules uit de package.json
3. type: npm audit fix
the verhelpt de meeste kwetsbaarheden verkregen door de npms. 
dit is altijd handig om na npm install te doen

vervolgens kun je je eigen .ts files maken in de hierarchie of code in de app.ts zetten.

als je het project wilt starten en afsluiten
1. type: npm run dev in de terminal
dit start de applicatie en opent hem.
2. ctrl + c in de terminal, daarna krijg je een prompt om Y in te drukken.
vervolgens enter en dat sluit de app zich






